/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Team 2 Kelas 05TPLE001
 * 1. Joni Prianto
 * 2. Dimas Angga Surya Wijaya
 * 3. Fahri Muhammad
 * 
 */
public class basisdata extends javax.swing.JFrame {

    int gaji;
    int pph21;
    int tunjangan;
    int thp;
    
    public basisdata() {
        setTitle("Aplikasi Perhitungan Gaji");
        initComponents();
    }
    
     private void ProsesGaji(){
        int pilihan=cmbpendidikan.getSelectedIndex();
        switch(pilihan){
            case 1: //Pendidikan SD
                if(Integer.parseInt(txtlamakerja.getText())<5){
                    gaji=1500000;
                    txtgaji.setText("1500000");
                } else if(Integer.parseInt(txtlamakerja.getText())>=5 
                        && Integer.parseInt(txtlamakerja.getText())<10){
                    gaji=2000000;
                    txtgaji.setText("2000000");
                } else if(Integer.parseInt(txtlamakerja.getText())>=10){
                    gaji=2500000;
                    txtgaji.setText("2500000");
                }                
            break;    
            case 2: //Pendidikan SMP
                if(Integer.parseInt(txtlamakerja.getText())<5){
                    gaji=3000000;
                    txtgaji.setText("3000000");
                } else if(Integer.parseInt(txtlamakerja.getText())>=5 
                        && Integer.parseInt(txtlamakerja.getText())<10){
                    gaji=3500000;
                    txtgaji.setText("3500000");
                } else if(Integer.parseInt(txtlamakerja.getText())>=10){
                    gaji=4000000;
                    txtgaji.setText("4000000");
                }
            break;
            case 3: //Pendidikan SMA
                if(Integer.parseInt(txtlamakerja.getText())<5){
                    gaji=4500000;
                    txtgaji.setText("4500000");
                } else if(Integer.parseInt(txtlamakerja.getText())>=5 
                        && Integer.parseInt(txtlamakerja.getText())<10){
                    gaji=5000000;
                    txtgaji.setText("5000000");
                } else if(Integer.parseInt(txtlamakerja.getText())>=10){
                    gaji=5500000;
                    txtgaji.setText("5500000");
                }
            break;
            case 4: //PENDIDIKAN S1
                if(Integer.parseInt(txtlamakerja.getText())<5){
                    gaji=7000000;
                    txtgaji.setText("7000000");
                } else if(Integer.parseInt(txtlamakerja.getText())>=5 
                        && Integer.parseInt(txtlamakerja.getText())<10){
                    gaji=8000000;
                    txtgaji.setText("8000000");
                } else if(Integer.parseInt(txtlamakerja.getText())>=10){
                    gaji=9000000;
                    txtgaji.setText("9000000");
                }
            break; //Pendidikan S2
            case 5:
                if(Integer.parseInt(txtlamakerja.getText())<5){
                    gaji=15000000;
                    txtgaji.setText("15000000");
                } else if(Integer.parseInt(txtlamakerja.getText())>=5 
                        && Integer.parseInt(txtlamakerja.getText())<10){
                    gaji=17000000;
                    txtgaji.setText("17000000");
                } else if(Integer.parseInt(txtlamakerja.getText())>=10){
                    gaji=20000000;
                    txtgaji.setText("20000000");
                }
            break;
         }
    }
     
     private void PPH21(){
         if(gaji>=10000000){
             double pph = 0.11*gaji;
             pph21 = (int) pph;
             txtpph21.setText(Integer.toString(pph21));
             
         } else if(gaji<10000000){
             pph21=0;
             txtpph21.setText("0");
         }
         ;
     }
     

    private void Tunjangan(){
         if(opsi1.isSelected()==true){
             tunjangan=1000000;
             txttunjangan.setText("1000000");
         } else if(opsi2.isSelected()==true){
             tunjangan=500000;
             txttunjangan.setText("500000");
         }
    }
    
     private void thp(){
        thp=gaji+tunjangan-pph21;
        System.out.println("gaji = "+gaji);
        System.out.println("tunjangan = "+tunjangan);
        System.out.println("pph21 = "+pph21);
        System.out.println("thp = "+thp);
        txtthp.setText(Integer.toString(thp));
    }
     
      private void bersih(){
        gaji=0;
        pph21=0;
        tunjangan=0;
        thp=0;
        
        cmbpendidikan.setSelectedIndex(0);
        opsi1.setSelected(false);
        opsi2.setSelected(false);
        txtnim.setText("");
        txtnama.setText("");
        txtlamakerja.setText("");
        txtgaji.setText("0");
        txtpph21.setText("0");
        txtthp.setText("0");
        txttunjangan.setText("0");
    }

            

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel9 = new javax.swing.JLabel();
        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtnim = new javax.swing.JTextField();
        txtnama = new javax.swing.JTextField();
        opsi1 = new javax.swing.JRadioButton();
        opsi2 = new javax.swing.JRadioButton();
        cmbpendidikan = new javax.swing.JComboBox<>();
        txtlamakerja = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtgaji = new javax.swing.JTextField();
        txtpph21 = new javax.swing.JTextField();
        txtthp = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        cmdbersih = new javax.swing.JButton();
        cmdhitung = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txttunjangan = new javax.swing.JTextField();

        jLabel9.setText("jLabel6");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("TUGAS BASIS DATA");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jLabel1.setText("NIM");

        jLabel2.setText("NAMA");

        jLabel3.setText("PENDIDIKAN");

        jLabel4.setText("STATUS");

        jLabel5.setText("LAMA KERJA");

        txtnim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnimActionPerformed(evt);
            }
        });

        txtnama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnamaActionPerformed(evt);
            }
        });

        buttonGroup1.add(opsi1);
        opsi1.setText("K");
        opsi1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opsi1ActionPerformed(evt);
            }
        });

        buttonGroup1.add(opsi2);
        opsi2.setText("TK");
        opsi2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opsi2ActionPerformed(evt);
            }
        });

        cmbpendidikan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-- Pilih --", "SD", "SMP", "SMA", "S1", "S2" }));
        cmbpendidikan.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cmbpendidikanItemStateChanged(evt);
            }
        });
        cmbpendidikan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbpendidikanActionPerformed(evt);
            }
        });

        txtlamakerja.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtlamakerjaActionPerformed(evt);
            }
        });

        jLabel6.setText("Gaji");

        jLabel7.setText("PPH21");

        jLabel8.setText("THP");

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel13.setText("TUGAS BASIS DATA");

        cmdbersih.setText("BERSIH");
        cmdbersih.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cmdbersihMouseClicked(evt);
            }
        });
        cmdbersih.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdbersihActionPerformed(evt);
            }
        });

        cmdhitung.setText("HITUNG");
        cmdhitung.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cmdhitungMouseClicked(evt);
            }
        });

        jLabel14.setText("Dibuat Oleh : Team 2");

        jLabel10.setText("Tunjangan");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(254, 254, 254)
                .addComponent(jLabel13)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel1)
                                .addComponent(jLabel3)
                                .addComponent(jLabel4)
                                .addComponent(jLabel2))
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(52, 52, 52)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtnama, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                            .addComponent(opsi2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(opsi1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cmbpendidikan, 0, 1, Short.MAX_VALUE)
                            .addComponent(txtnim)
                            .addComponent(txtlamakerja))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addGap(92, 92, 92)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtthp, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtpph21, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txttunjangan, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtgaji, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(cmdhitung, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(49, 49, 49)
                                .addComponent(cmdbersih, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel7)
                            .addComponent(jLabel10))
                        .addGap(111, 111, 111))
                    .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel13)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtnim, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(txtgaji, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtnama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10))
                        .addGap(13, 13, 13)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(cmbpendidikan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txttunjangan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtpph21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(opsi1)
                                    .addComponent(jLabel4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(opsi2))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel8)
                                    .addComponent(txtthp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(24, 24, 24)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtlamakerja, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(cmdhitung, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmdbersih, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 85, Short.MAX_VALUE))))
        );

        cmbpendidikan.getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtnamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnamaActionPerformed
        
    }//GEN-LAST:event_txtnamaActionPerformed

    private void txtlamakerjaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtlamakerjaActionPerformed
        ProsesGaji();
        Tunjangan();
        PPH21();
    }//GEN-LAST:event_txtlamakerjaActionPerformed

    private void txtnimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnimActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnimActionPerformed

    private void cmdbersihActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdbersihActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmdbersihActionPerformed

    private void cmbpendidikanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbpendidikanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbpendidikanActionPerformed

    private void opsi1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opsi1ActionPerformed
       
    }//GEN-LAST:event_opsi1ActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        bersih();
    }//GEN-LAST:event_formWindowOpened

    private void cmbpendidikanItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cmbpendidikanItemStateChanged
        
    }//GEN-LAST:event_cmbpendidikanItemStateChanged

    private void opsi2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opsi2ActionPerformed
       
    }//GEN-LAST:event_opsi2ActionPerformed

    private void cmdbersihMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cmdbersihMouseClicked
        bersih();
    }//GEN-LAST:event_cmdbersihMouseClicked

    private void cmdhitungMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cmdhitungMouseClicked
        ProsesGaji();
        Tunjangan();
        PPH21();
        thp();
    }//GEN-LAST:event_cmdhitungMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(basisdata.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(basisdata.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(basisdata.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(basisdata.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new basisdata().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cmbpendidikan;
    private javax.swing.JButton cmdbersih;
    private javax.swing.JButton cmdhitung;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JRadioButton opsi1;
    private javax.swing.JRadioButton opsi2;
    private javax.swing.JTextField txtgaji;
    private javax.swing.JTextField txtlamakerja;
    private javax.swing.JTextField txtnama;
    private javax.swing.JTextField txtnim;
    private javax.swing.JTextField txtpph21;
    private javax.swing.JTextField txtthp;
    private javax.swing.JTextField txttunjangan;
    // End of variables declaration//GEN-END:variables
}

